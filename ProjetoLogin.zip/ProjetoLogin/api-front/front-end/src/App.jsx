import { useEffect, useState } from 'react'
import axios from 'axios'
import './App.css';

function App() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [cpf, setCpf] = useState('')
  const [data,setData] = useState([]);  

  useEffect(()=> {
    console.log(data)
    console.log(data.map((nomes)=> nomes.name))
  },[data]);

  


  if (window.location.href === 'http://localhost:5173/Home') {
    return(
      <>
        <h1>HOME EBAA</h1>
      </>
    )
  }

  
  
  if (window.location.href === 'http://localhost:5173/Cadastro') {
    return (
    <>
    <h1>Página de Cadastro</h1>
    <input style={style.input} type="text" placeholder='Nome' onChange={(e) => setName(e.target.value)}/>
    <input style={style.input} type="number" maxLength={11} placeholder='CPF' onChange={(e) => setCpf(e.target.value)}/>
    <input style={style.input} type="text" placeholder='Email' onChange={(e) => setEmail(e.target.value)}/>
    <br></br>
    <button style={style.botao} onClick={ADDEIR}>
        Se Cadastrar
    </button>
    </>)
  } 
  
  else {
    return (
    <>
      <h1>Login</h1>
 
      <input style={style.input} type="text"  placeholder='Nome' onChange={(e) => setName(e.target.value)}/>
      <input style={style.input} type="text"  placeholder='CPF' onChange={(e) => setCpf(e.target.value)}/>

      <br></br>

      <button style={style.botao} onClick={Verificar}>
        Entrar
      </button>
      <br></br>
      <br></br>
      <button style={style.botao} onClick={IrCadastro}>
        Me Cadastrar
      </button>


    </>);
  }
  async function getUsers(){
    const response = await axios.get('http://127.0.0.1:8000/alunos/')
    console.log(response.data)
  }

  async function addUser(){
    const response = await axios.post ('http://127.0.0.1:8000/alunos/', {
      name: name,
      email: email,
      cpf: cpf
    })
  }

  function Verificar(){
    if (name === "Vinicius"){
      console.log("Nome: ",name)
      IrHome();}
    else {
      console.log("Credenciais incorretas")
      }
  }

  function ADDEIR(){
    IrLogin();
    addUser();
  }
  function IrCadastro(){
    window.location.assign('http://localhost:5173/Cadastro')
  }

  function IrHome(){
      // Credenciais válidas, define o estado como logado
      window.location.assign('http://localhost:5173/Home')    
      console.log('Login successful');

     }
  }

  function IrLogin(){
    window.location.assign('http://localhost:5173/Login')    
  }

  function verurl(){
    console.log(window.location.href)
  }




export default App

const style ={
  input:{
    width: '100px',
    height: '40px',
    fontSize: '20px',
    backgroundColor:'#995c16',
    color: 'green',

  },
  botao:{
    backgroundColor: '#c4945a',
    color: '#213547',
  },
}
